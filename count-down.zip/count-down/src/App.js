import './App.css';
import React from 'react';

// class App extends React.Component {
//   // 表示类的构造函数，网页的初值
//   constructor(props) {
//     super(props)
//     // 网页的全局变量，初始值
//     this.state = {
//       minute: 60,
//       second: 60
//     }
//     this.start = this.start.bind(this)
//     this.no = this.no.bind(this)
//     this.end = this.end.bind(this)
//   }

//   start() {

//     if (this.state.second > 0) {

//       this.setState({
//         minute: this.state.minute,
//         second: this.state.second - 1
//       })

//     }

//     else {

//       this.setState({
//         minute: this.state.minute - 1,
//         second: this.state.second + 60
//       })

//     }

//   }

//   no() {
//     // 内置函数，表示每1000ms，执行一次state函数
//     this.id = setInterval(this.start, 1000)
//   }

//   end() {
//     clearInterval(this.id)
//   }

//   render() {
//     return (
//       <div className="App">

//         <header className="App-header">
//           <div className="App-time" id="container">
//             {this.state.minute} : {this.state.second}
//           </div>

//           <div>
//             <p>
//               =============================
//             </p>
//           </div>

//           <div>
//           {/* onClick	按钮被按下之后执行的函数，onclick是完成一次完整的按下和松开 */}
//             <button  className="App-b1" onClick={this.no}>
//             start
//             </button>

//             <span className="App-span">
//               ===  
//             </span>

//             <button className="App-b2" onClick={this.end}>
//             &nbsp;end&nbsp;
//             </button>
//           </div>
//         </header>
        
//       </div>

//     );
//   }
// }


// export default App;



class App extends React.Component {
  state = {
    min: 59,
    second: 59,
    timer: null,
  };

  count = () => {
    if (this.state.second > 0) {
      this.setState({
        min: this.state.min,
        second: this.state.second - 1,
      })
    } else if (this.state.min > 0) {
      this.setState({
        min: this.state.min - 1,
        second: 59,
      })
    } else {
      clearInterval(this.state.timer);
    }
  }

  // 只是调用，所以不需要参数
  start = () => {
    const interval = setInterval(this.count, 1000);
    this.setState({
      timer: interval,
    });
  }

  stop = () => {
    clearInterval(this.state.timer);
    this.setState({
      timer: null,
    })
  }

  reset = () => {
    if (this.state.timer) {
      clearInterval(this.state.timer);
    }
    this.setState({
      timer: null,
      min: 59,
      second: 59,
    })
  }
    
  render() {
    return (
      <div className="App">
        <header className="App-header">
          <p className = 'App-time'>
            {this.state.min}:{this.state.second}
          </p>
          <button className="App-b1" onClick={this.start}>开始倒计时</button>
          <button className="App-b2" onClick={this.stop}>停止倒计时</button>
          <button className="App-b3" onClick={this.reset}>重新倒计时</button>
        </header>
      </div>
    );
  }
}

export default App;