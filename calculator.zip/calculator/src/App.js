import './App.css';
import React from 'react';

class Timer extends React.Component {
  state = {
    a: ' ',
    b: ' ',
  };

  setA = (a) => {
    // isNaN和Number是内置函数，Number是强制类型转换，因为input标签默认输入字符串！！！！！
    // const input = isNaN(a.currentTarget.value) ? 0 : Number(a.currentTarget.value)
    // let input1
    const input = a.currentTarget.value
    this.setState({
      a: input,
    });
  }

  setB = (b) => {
    // const input = isNaN(b.currentTarget.value) ? 0 : Number(b.currentTarget.value)
    // let input2
    const input = b.currentTarget.value
    this.setState({
      b: input,
    });
  }

  render() {
    return (
      <div className ="App">
        <header className ="App-header">
          <p>
            {/* onChange表示： */}
            {/* <input  className = 'App-input1' onChange={this.setA} value={this.state.a} /> + <input className = 'App-input2' onChange={this.setB} value={this.state.b} /> = {this.state.a + this.state.b}     Number(this.state.a + this.state.b)不对,这等同于字符串相加!!! */}
            <input className = 'App-input1' onChange={this.setA} value={this.state.a} /> + <input className = 'App-input2' onChange={this.setB} value={this.state.b} /> = <input className = 'App-input3' value = {Number(this.state.a) + Number(this.state.b)}/>
            <br/>

            <input className = 'App-input1' onChange={this.setA} value={this.state.a} /> - <input className = 'App-input2' onChange={this.setB} value={this.state.b} /> = <input className = 'App-input3' value = {Number(this.state.a - this.state.b)}/>
            <br/>

            <input className = 'App-input1' onChange={this.setA} value={this.state.a} /> * <input className = 'App-input2' onChange={this.setB} value={this.state.b} /> = <input className = 'App-input3' value = {Number(this.state.a * this.state.b)}/>
            <br/>

            <input className = 'App-input1' onChange={this.setA} value={this.state.a} /> / <input className = 'App-input2' onChange={this.setB} value={this.state.b} /> = <input className = 'App-input3' value = {Number(this.state.a / this.state.b)}/>
            <br/>

          </p>
        </header>
      </div>
    );
  }
}

export default Timer;
