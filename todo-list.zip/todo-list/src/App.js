import './App.css';
import React,{Component} from 'react';
import materialize from 'npm';

class ToDoList extends React.Component {
  state = {
    todos: [
      {id:1, content:'买菜'},
      {id:1, content:'打扫卫生'},
      {id:1, content:'阅读书籍'},
    ]
  }
  render() {
    return(
      <div className = 'todo-app container'>
        <h1 className = 'center blue-text'>任务列表</h1>
        <todos todos = {this.state.todos}/>
      </div>
    );
  }
}
    

export default ToDoList;
