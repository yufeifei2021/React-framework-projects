import React from 'react';
import {Button , Input} from 'antd';
import './App.css';

class App extends React.Component {
  state = {
    user: '',
    computer: '',
    result: null,
  }

  reset = () => {
    if(this.state.result){
      clearInterval(this.state.result);
    };
    this.setState({
      result: null,
    })

    const Computer = () => {
      const computer = this.state.computer;
      computer = Math.ceil(Math.random()*3);
      console.log ('电脑的猜拳结果为');
    }

    const User = (user) => {
      const user = this.state.user;
      console.log ('玩家的猜拳结果为');
    }
    
    function game () {
    const a = 1;//石头
    const b = 2;//剪刀
    const c = 3;//布
    const user = this.state.user;
    const computer = this.state.computer;
    const result = this.state.result;
    if (user == computer){
      return '平局！';
    }else if (user == 1 && computer == 2 || user == 2 && computer == 3 || user == 3 && computer == 1  ){
      return '玩家胜出！';
    }else 
      return '电脑胜出！';
    }

  }

  render(){
    return(
      <div className = 'App-game'>
        <p className = 'App-title'>人机猜拳游戏！</p>
        {'玩家出拳：'}&nbsp;{this.state.user}
        <br/><br/>
        {'电脑出拳：'}&nbsp;{this.state.computer}<Input onChange = {this.User} value = {this.state.user}/>
        <br/>
        {'猜拳结果：'}&nbsp;{this.state.result}
        <br/><br/>
        <Button onClick = {this.reset}>重新游戏</Button>
      </div>
    );
  }
}

export default App;
