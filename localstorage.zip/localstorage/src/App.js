import './App.css';
import React from 'react';

  //componentDidMount将数据保存在本地，实现***再次***刷新页面，会保留之前的数据       放进willmount也可以
class Root extends React.Component {
    state = {
      isState: ' '
    }

    //取数据，只在网页初始化的时候进行
    componentWillMount = () => {
      const persistState = localStorage.getItem('rootState');
      
      if (persistState) {

          this.setState({
            isState: persistState
          });

      }
      // localStorage.setItem('rootState', this.state.isState);
    }

    //存数据，负责和input框进行绑定,是ss的处理函数
    ss = (isState) => {
      const input = isState.currentTarget.value
      this.setState ({
        isState: input
      })
      const currentState = localStorage.setItem('rootState', input)
    }
  

  render() {
    return (
      <div className="App">
        <header className="App-header">
          {/* <input className = 'App-input1' onChange={} value={}/> */}
          <input className='App-input1' onChange={this.ss} value={this.state.isState} />
        </header>
      </div>
    );
  }
}
  

    

export default Root;
