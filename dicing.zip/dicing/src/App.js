import './App.css';
import React, { Component } from 'react';

class App extends React.Component {

    state = {
      result: '请投掷！'
    };

    start = () => {
      const interval = Math.ceil(Math.random()*6);
      this.setState({
        result: interval,
      })
    }

  render() {
    return (
      <div className="App">

        <header className="App-header">

          <div className="App-result">
              {'您此次投掷结果为：'}&nbsp;{this.state.result}
             
           <p></p>

          </div>

          <div>
          {/* onClick	按钮被按下之后执行的函数，onclick是完成一次完整的按下和松开 */}
            <button  className="App-b" onClick={this.start}>小赌怡情</button>
          </div>
        </header>
        
      </div>

    );
  }
}


export default App;